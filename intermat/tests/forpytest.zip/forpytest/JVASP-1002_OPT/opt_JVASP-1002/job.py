from jarvis.tasks.vasp.vasp import VaspJob
from jarvis.db.jsonutils import loadjson
d=loadjson("/rk3/knc6/OPT_DB/JVASP-1002_R2SCAN/opt_JVASP-1002/VaspJob_opt_JVASP-1002_job.json")
v=VaspJob.from_dict(d)
v.runjob()
